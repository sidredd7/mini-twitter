"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Card, CardContent } from "@/components/ui/card"
import { LogOut, User } from "lucide-react"
import PostItem from "@/components/post-item"
import ProfileModal from "@/components/profile-modal"

interface Post {
  _id: string
  content: string
  author: {
    _id: string
    username: string
  }
  createdAt: string
}

interface UserType {
  id: string
  username: string
  email: string
}

export default function Feed() {
  const [posts, setPosts] = useState<Post[]>([])
  const [newPost, setNewPost] = useState("")
  const [loading, setLoading] = useState(false)
  const [user, setUser] = useState<UserType | null>(null)
  const [showProfile, setShowProfile] = useState(false)

  useEffect(() => {
    const userData = localStorage.getItem("user")
    if (userData) {
      setUser(JSON.parse(userData))
    }
    fetchPosts()
  }, [])

  const fetchPosts = async () => {
    try {
      const token = localStorage.getItem("token")
      const response = await fetch("https://mini-twitter-api-vy9q.onrender.com/api/posts", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })

      if (response.ok) {
        const data = await response.json()
        setPosts(data)
      }
    } catch (err) {
      console.error("Erro ao carregar posts:", err)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!newPost.trim()) return

    setLoading(true)
    try {
      const token = localStorage.getItem("token")
      const response = await fetch("https://mini-twitter-api-vy9q.onrender.com/api/posts", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ content: newPost }),
      })

      if (response.ok) {
        setNewPost("")
        fetchPosts()
      }
    } catch (err) {
      console.error("Erro ao criar post:", err)
    } finally {
      setLoading(false)
    }
  }

  const handleLogout = () => {
    localStorage.removeItem("token")
    localStorage.removeItem("user")
    window.location.reload()
  }

  const handleDeletePost = async (postId: string) => {
    try {
      const token = localStorage.getItem("token")
      const response = await fetch(`https://mini-twitter-api-vy9q.onrender.com/api/posts/${postId}`, {
        method: "DELETE",
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })

      if (response.ok) {
        fetchPosts()
      }
    } catch (err) {
      console.error("Erro ao deletar post:", err)
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="max-w-2xl mx-auto px-4 py-3 flex items-center justify-between">
          <h1 className="text-xl font-bold">Mini Twitter</h1>
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="sm" onClick={() => setShowProfile(true)} className="flex items-center gap-2">
              <User className="h-4 w-4" />
              <span className="hidden sm:inline">{user?.username}</span>
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleLogout}
              className="flex items-center gap-2 text-red-600 hover:text-red-700"
            >
              <LogOut className="h-4 w-4" />
              <span className="hidden sm:inline">Sair</span>
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-2xl mx-auto px-4 py-6">
        {/* Create Post */}
        <Card className="mb-6">
          <CardContent className="p-4">
            <form onSubmit={handleSubmit}>
              <div className="flex gap-3">
                <Avatar className="h-10 w-10">
                  <AvatarFallback>{user?.username?.charAt(0).toUpperCase() || "U"}</AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <Textarea
                    value={newPost}
                    onChange={(e) => setNewPost(e.target.value)}
                    placeholder="O que está acontecendo?"
                    className="border-none resize-none focus:ring-0 p-0 text-lg"
                    maxLength={280}
                  />
                  <div className="flex items-center justify-between mt-3">
                    <span className="text-sm text-gray-500">{newPost.length}/280</span>
                    <Button type="submit" disabled={loading || !newPost.trim()} className="rounded-full">
                      {loading ? "Publicando..." : "Publicar"}
                    </Button>
                  </div>
                </div>
              </div>
            </form>
          </CardContent>
        </Card>

        {/* Posts Feed */}
        <div className="space-y-4">
          {posts.map((post) => (
            <PostItem key={post._id} post={post} currentUserId={user?.id} onDelete={handleDeletePost} />
          ))}

          {posts.length === 0 && (
            <div className="text-center py-12">
              <p className="text-gray-500">Nenhum post ainda. Seja o primeiro a postar!</p>
            </div>
          )}
        </div>
      </main>

      {showProfile && (
        <ProfileModal
          onClose={() => setShowProfile(false)}
          onUserUpdate={(updatedUser) => {
            setUser(updatedUser)
            localStorage.setItem("user", JSON.stringify(updatedUser))
          }}
        />
      )}
    </div>
  )
}
