"use client"

import { useState } from "react"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Heart, MessageCircle, Repeat2, Share, MoreHorizontal, Trash2 } from "lucide-react"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

interface Post {
  _id: string
  content: string
  author: {
    _id: string
    username: string
  }
  createdAt: string
}

interface PostItemProps {
  post: Post
  currentUserId?: string
  onDelete: (postId: string) => void
}

export default function PostItem({ post, currentUserId, onDelete }: PostItemProps) {
  const [liked, setLiked] = useState(false)
  const [likeCount, setLikeCount] = useState(0)

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    const now = new Date()
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60))

    if (diffInHours < 1) {
      const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60))
      return `${diffInMinutes}min`
    } else if (diffInHours < 24) {
      return `${diffInHours}h`
    } else {
      const diffInDays = Math.floor(diffInHours / 24)
      return `${diffInDays}d`
    }
  }

  const handleLike = () => {
    setLiked(!liked)
    setLikeCount((prev) => (liked ? prev - 1 : prev + 1))
  }

  const isOwner = currentUserId === post.author._id

  return (
    <Card className="hover:bg-gray-50 transition-colors">
      <CardContent className="p-4">
        <div className="flex gap-3">
          <Avatar className="h-10 w-10">
            <AvatarFallback>{post.author.username.charAt(0).toUpperCase()}</AvatarFallback>
          </Avatar>

          <div className="flex-1">
            <div className="flex items-center gap-2 mb-1">
              <span className="font-semibold text-gray-900">{post.author.username}</span>
              <span className="text-gray-500 text-sm">· {formatDate(post.createdAt)}</span>

              {isOwner && (
                <div className="ml-auto">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => onDelete(post._id)} className="text-red-600 focus:text-red-600">
                        <Trash2 className="h-4 w-4 mr-2" />
                        Deletar
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              )}
            </div>

            <p className="text-gray-900 mb-3 whitespace-pre-wrap">{post.content}</p>

            <div className="flex items-center gap-6 text-gray-500">
              <Button variant="ghost" size="sm" className="flex items-center gap-2 hover:text-blue-600 p-0 h-auto">
                <MessageCircle className="h-4 w-4" />
                <span className="text-sm">0</span>
              </Button>

              <Button variant="ghost" size="sm" className="flex items-center gap-2 hover:text-green-600 p-0 h-auto">
                <Repeat2 className="h-4 w-4" />
                <span className="text-sm">0</span>
              </Button>

              <Button
                variant="ghost"
                size="sm"
                onClick={handleLike}
                className={`flex items-center gap-2 p-0 h-auto ${
                  liked ? "text-red-600 hover:text-red-700" : "hover:text-red-600"
                }`}
              >
                <Heart className={`h-4 w-4 ${liked ? "fill-current" : ""}`} />
                <span className="text-sm">{likeCount}</span>
              </Button>

              <Button variant="ghost" size="sm" className="flex items-center gap-2 hover:text-blue-600 p-0 h-auto">
                <Share className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
