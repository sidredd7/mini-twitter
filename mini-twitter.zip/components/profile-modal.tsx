"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { X, Edit2, Save } from "lucide-react"
import PostItem from "@/components/post-item"

interface User {
  _id: string
  username: string
  email: string
  createdAt: string
}

interface Post {
  _id: string
  content: string
  author: {
    _id: string
    username: string
  }
  createdAt: string
}

interface ProfileModalProps {
  onClose: () => void
  onUserUpdate: (user: any) => void
}

export default function ProfileModal({ onClose, onUserUpdate }: ProfileModalProps) {
  const [user, setUser] = useState<User | null>(null)
  const [posts, setPosts] = useState<Post[]>([])
  const [isEditing, setIsEditing] = useState(false)
  const [editUsername, setEditUsername] = useState("")
  const [editEmail, setEditEmail] = useState("")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")

  useEffect(() => {
    fetchProfile()
    fetchMyPosts()
  }, [])

  const fetchProfile = async () => {
    try {
      const token = localStorage.getItem("token")
      const response = await fetch("https://mini-twitter-api-vy9q.onrender.com/api/users/profile", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })

      if (response.ok) {
        const data = await response.json()
        setUser(data)
        setEditUsername(data.username)
        setEditEmail(data.email)
      }
    } catch (err) {
      console.error("Erro ao carregar perfil:", err)
    }
  }

  const fetchMyPosts = async () => {
    try {
      const token = localStorage.getItem("token")
      const response = await fetch("https://mini-twitter-api-vy9q.onrender.com/api/posts/my-posts", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })

      if (response.ok) {
        const data = await response.json()
        setPosts(data)
      }
    } catch (err) {
      console.error("Erro ao carregar posts:", err)
    }
  }

  const handleSave = async () => {
    setLoading(true)
    setError("")

    try {
      const token = localStorage.getItem("token")
      const response = await fetch("https://mini-twitter-api-vy9q.onrender.com/api/users/profile", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          username: editUsername,
          email: editEmail,
        }),
      })

      const data = await response.json()

      if (response.ok) {
        setUser(data.user)
        setIsEditing(false)
        onUserUpdate(data.user)
      } else {
        setError(data.message || "Erro ao atualizar perfil")
      }
    } catch (err) {
      setError("Erro de conexão. Tente novamente.")
    } finally {
      setLoading(false)
    }
  }

  const handleDeletePost = async (postId: string) => {
    try {
      const token = localStorage.getItem("token")
      const response = await fetch(`https://mini-twitter-api-vy9q.onrender.com/api/posts/${postId}`, {
        method: "DELETE",
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })

      if (response.ok) {
        fetchMyPosts()
      }
    } catch (err) {
      console.error("Erro ao deletar post:", err)
    }
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("pt-BR", {
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg w-full max-w-2xl max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b">
          <h2 className="text-xl font-bold">Perfil</h2>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </div>

        <div className="overflow-y-auto max-h-[calc(90vh-80px)]">
          {/* Profile Info */}
          <div className="p-6 border-b">
            <div className="flex items-start gap-4">
              <Avatar className="h-20 w-20">
                <AvatarFallback className="text-2xl">{user?.username?.charAt(0).toUpperCase() || "U"}</AvatarFallback>
              </Avatar>

              <div className="flex-1">
                {isEditing ? (
                  <div className="space-y-4">
                    {error && (
                      <div className="bg-red-50 border border-red-200 text-red-600 px-3 py-2 rounded-md text-sm">
                        {error}
                      </div>
                    )}

                    <div>
                      <Label htmlFor="username">Nome de usuário</Label>
                      <Input
                        id="username"
                        value={editUsername}
                        onChange={(e) => setEditUsername(e.target.value)}
                        className="mt-1"
                      />
                    </div>

                    <div>
                      <Label htmlFor="email">Email</Label>
                      <Input
                        id="email"
                        type="email"
                        value={editEmail}
                        onChange={(e) => setEditEmail(e.target.value)}
                        className="mt-1"
                      />
                    </div>

                    <div className="flex gap-2">
                      <Button onClick={handleSave} disabled={loading} size="sm">
                        <Save className="h-4 w-4 mr-2" />
                        {loading ? "Salvando..." : "Salvar"}
                      </Button>
                      <Button
                        variant="outline"
                        onClick={() => {
                          setIsEditing(false)
                          setEditUsername(user?.username || "")
                          setEditEmail(user?.email || "")
                          setError("")
                        }}
                        size="sm"
                      >
                        Cancelar
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <h3 className="text-2xl font-bold">{user?.username}</h3>
                      <Button variant="outline" size="sm" onClick={() => setIsEditing(true)}>
                        <Edit2 className="h-4 w-4 mr-2" />
                        Editar
                      </Button>
                    </div>
                    <p className="text-gray-600 mb-2">{user?.email}</p>
                    <p className="text-gray-500 text-sm">
                      Membro desde {user?.createdAt ? formatDate(user.createdAt) : ""}
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Posts */}
          <div className="p-6">
            <h4 className="text-lg font-semibold mb-4">Seus posts ({posts.length})</h4>

            <div className="space-y-4">
              {posts.map((post) => (
                <PostItem key={post._id} post={post} currentUserId={user?._id} onDelete={handleDeletePost} />
              ))}

              {posts.length === 0 && (
                <div className="text-center py-8">
                  <p className="text-gray-500">Você ainda não fez nenhum post.</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
