/**
 * View para gerenciamento da interface de autenticação
 * Responsável por manipular elementos DOM relacionados ao login/registro
 */
class AuthView {
  constructor() {
    this.initializeElements()
    this.bindEvents()
  }

  /**
   * Inicializa referências aos elementos DOM
   */
  initializeElements() {
    // Containers
    this.authContainer = document.getElementById("auth-container")
    this.loginForm = document.getElementById("login-form")
    this.registerForm = document.getElementById("register-form")

    // Formulários
    this.loginFormElement = document.getElementById("login-form-element")
    this.registerFormElement = document.getElementById("register-form-element")

    // Campos de login
    this.loginEmail = document.getElementById("login-email")
    this.loginPassword = document.getElementById("login-password")
    this.loginError = document.getElementById("login-error")

    // Campos de registro
    this.registerUsername = document.getElementById("register-username")
    this.registerEmail = document.getElementById("register-email")
    this.registerPassword = document.getElementById("register-password")
    this.registerError = document.getElementById("register-error")

    // Botões
    this.showRegisterBtn = document.getElementById("show-register")
    this.showLoginBtn = document.getElementById("show-login")
  }

  /**
   * Vincula eventos aos elementos
   */
  bindEvents() {
    // Toggle entre login e registro
    this.showRegisterBtn.addEventListener("click", () => this.showRegister())
    this.showLoginBtn.addEventListener("click", () => this.showLogin())
  }

  /**
   * Mostra o container de autenticação
   */
  show() {
    this.authContainer.classList.remove("hidden")
  }

  /**
   * Esconde o container de autenticação
   */
  hide() {
    this.authContainer.classList.add("hidden")
  }

  /**
   * Mostra formulário de registro
   */
  showRegister() {
    this.loginForm.classList.add("hidden")
    this.registerForm.classList.remove("hidden")
    this.clearErrors()
    this.clearForms()
  }

  /**
   * Mostra formulário de login
   */
  showLogin() {
    this.registerForm.classList.add("hidden")
    this.loginForm.classList.remove("hidden")
    this.clearErrors()
    this.clearForms()
  }

  /**
   * Obtém dados do formulário de login
   * @returns {Object} Dados do login
   */
  getLoginData() {
    return {
      email: this.loginEmail.value.trim(),
      password: this.loginPassword.value,
    }
  }

  /**
   * Obtém dados do formulário de registro
   * @returns {Object} Dados do registro
   */
  getRegisterData() {
    return {
      username: this.registerUsername.value.trim(),
      email: this.registerEmail.value.trim(),
      password: this.registerPassword.value,
    }
  }

  /**
   * Mostra erro no formulário de login
   * @param {string} message - Mensagem de erro
   */
  showLoginError(message) {
    this.loginError.textContent = message
    this.loginError.classList.remove("hidden")
  }

  /**
   * Mostra erro no formulário de registro
   * @param {string} message - Mensagem de erro
   */
  showRegisterError(message) {
    this.registerError.textContent = message
    this.registerError.classList.remove("hidden")
  }

  /**
   * Limpa todas as mensagens de erro
   */
  clearErrors() {
    this.loginError.classList.add("hidden")
    this.registerError.classList.add("hidden")
  }

  /**
   * Limpa todos os formulários
   */
  clearForms() {
    this.loginFormElement.reset()
    this.registerFormElement.reset()
  }

  /**
   * Define estado de loading para botão de login
   * @param {boolean} loading - Estado de loading
   */
  setLoginLoading(loading) {
    const btn = this.loginFormElement.querySelector('button[type="submit"]')
    const btnText = btn.querySelector(".btn-text")
    const btnLoading = btn.querySelector(".btn-loading")

    btn.disabled = loading

    if (loading) {
      btnText.classList.add("hidden")
      btnLoading.classList.remove("hidden")
      btn.classList.add("btn-loading")
    } else {
      btnText.classList.remove("hidden")
      btnLoading.classList.add("hidden")
      btn.classList.remove("btn-loading")
    }
  }

  /**
   * Define estado de loading para botão de registro
   * @param {boolean} loading - Estado de loading
   */
  setRegisterLoading(loading) {
    const btn = this.registerFormElement.querySelector('button[type="submit"]')
    const btnText = btn.querySelector(".btn-text")
    const btnLoading = btn.querySelector(".btn-loading")

    btn.disabled = loading

    if (loading) {
      btnText.classList.add("hidden")
      btnLoading.classList.remove("hidden")
      btn.classList.add("btn-loading")
    } else {
      btnText.classList.remove("hidden")
      btnLoading.classList.add("hidden")
      btn.classList.remove("btn-loading")
    }
  }

  /**
   * Valida dados de login
   * @param {Object} data - Dados para validação
   * @returns {boolean} True se válido
   */
  validateLoginData(data) {
    if (!data.email || !data.password) {
      this.showLoginError("Todos os campos são obrigatórios")
      return false
    }

    if (!this.isValidEmail(data.email)) {
      this.showLoginError("Email inválido")
      return false
    }

    return true
  }

  /**
   * Valida dados de registro
   * @param {Object} data - Dados para validação
   * @returns {boolean} True se válido
   */
  validateRegisterData(data) {
    if (!data.username || !data.email || !data.password) {
      this.showRegisterError("Todos os campos são obrigatórios")
      return false
    }

    if (data.username.length < 3) {
      this.showRegisterError("Nome de usuário deve ter pelo menos 3 caracteres")
      return false
    }

    if (!this.isValidEmail(data.email)) {
      this.showRegisterError("Email inválido")
      return false
    }

    if (data.password.length < 6) {
      this.showRegisterError("Senha deve ter pelo menos 6 caracteres")
      return false
    }

    return true
  }

  /**
   * Valida formato de email
   * @param {string} email - Email para validação
   * @returns {boolean} True se válido
   */
  isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    return emailRegex.test(email)
  }
}
