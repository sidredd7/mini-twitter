/**
 * View para gerenciamento da interface do perfil
 * Responsável por manipular elementos DOM relacionados ao perfil do usuário
 */
class ProfileView {
  constructor() {
    this.initializeElements()
    this.bindEvents()
  }

  /**
   * Inicializa referências aos elementos DOM
   */
  initializeElements() {
    // Modal
    this.profileModal = document.getElementById("profile-modal")
    this.closeProfileBtn = document.getElementById("close-profile")

    // Profile display
    this.profileView = document.getElementById("profile-view")
    this.profileEdit = document.getElementById("profile-edit")
    this.profileAvatarDisplay = document.getElementById("profile-avatar-display")
    this.profileUsername = document.getElementById("profile-username")
    this.profileEmail = document.getElementById("profile-email")
    this.profileDate = document.getElementById("profile-date")

    // Edit form
    this.editProfileBtn = document.getElementById("edit-profile-btn")
    this.profileEditForm = document.getElementById("profile-edit-form")
    this.editUsername = document.getElementById("edit-username")
    this.editEmail = document.getElementById("edit-email")
    this.cancelEditBtn = document.getElementById("cancel-edit")
    this.profileEditError = document.getElementById("profile-edit-error")

    // User posts
    this.userPostsTitle = document.getElementById("user-posts-title")
    this.userPostsContainer = document.getElementById("user-posts-container")
    this.noUserPosts = document.getElementById("no-user-posts")
  }

  /**
   * Vincula eventos aos elementos
   */
  bindEvents() {
    // Fechar modal
    this.closeProfileBtn.addEventListener("click", () => this.hide())
    this.profileModal.addEventListener("click", (e) => {
      if (e.target === this.profileModal || e.target.classList.contains("modal-overlay")) {
        this.hide()
      }
    })

    // Toggle edit mode
    this.editProfileBtn.addEventListener("click", () => this.showEditMode())
    this.cancelEditBtn.addEventListener("click", () => this.hideEditMode())

    // Escape key para fechar modal
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape" && !this.profileModal.classList.contains("hidden")) {
        this.hide()
      }
    })
  }

  /**
   * Mostra o modal de perfil
   */
  show() {
    this.profileModal.classList.remove("hidden")
    document.body.style.overflow = "hidden"
  }

  /**
   * Esconde o modal de perfil
   */
  hide() {
    this.profileModal.classList.add("hidden")
    document.body.style.overflow = ""
    this.hideEditMode()
    this.clearError()
  }

  /**
   * Mostra modo de edição
   */
  showEditMode() {
    this.profileView.classList.add("hidden")
    this.profileEdit.classList.remove("hidden")
  }

  /**
   * Esconde modo de edição
   */
  hideEditMode() {
    this.profileEdit.classList.add("hidden")
    this.profileView.classList.remove("hidden")
    this.clearError()
  }

  /**
   * Renderiza dados do perfil
   * @param {Object} user - Dados do usuário
   */
  renderProfile(user) {
    // Avatar
    this.profileAvatarDisplay.textContent = user.username.charAt(0).toUpperCase()

    // Informações básicas
    this.profileUsername.textContent = user.username
    this.profileEmail.textContent = user.email
    this.profileDate.textContent = `Membro desde ${this.formatDate(user.createdAt)}`

    // Preencher formulário de edição
    this.editUsername.value = user.username
    this.editEmail.value = user.email
  }

  /**
   * Renderiza posts do usuário
   * @param {Array} posts - Lista de posts do usuário
   * @param {string} currentUserId - ID do usuário atual
   */
  renderUserPosts(posts, currentUserId) {
    // Atualizar título
    this.userPostsTitle.textContent = `Seus posts (${posts.length})`

    if (posts.length === 0) {
      this.userPostsContainer.classList.add("hidden")
      this.noUserPosts.classList.remove("hidden")
      return
    }

    this.noUserPosts.classList.add("hidden")
    this.userPostsContainer.classList.remove("hidden")

    this.userPostsContainer.innerHTML = posts.map((post) => this.createPostHTML(post, currentUserId)).join("")
  }

  /**
   * Cria HTML para um post (similar ao FeedView)
   * @param {Object} post - Dados do post
   * @param {string} currentUserId - ID do usuário atual
   * @returns {string} HTML do post
   */
  createPostHTML(post, currentUserId) {
    const isOwner = currentUserId === post.author._id
    const formattedDate = this.formatDate(post.createdAt)
    const authorInitial = post.author.username.charAt(0).toUpperCase()

    return `
            <article class="post-card" data-post-id="${post._id}">
                <div class="post-content">
                    <div class="post-avatar">
                        <div class="avatar">${authorInitial}</div>
                    </div>
                    
                    <div class="post-body">
                        <div class="post-header">
                            <span class="post-author">${post.author.username}</span>
                            <span class="post-date">· ${formattedDate}</span>
                            
                            ${
                              isOwner
                                ? `
                                <div class="post-menu">
                                    <button class="post-menu-btn" data-post-id="${post._id}">⋯</button>
                                    <div class="post-menu-dropdown hidden">
                                        <button class="post-menu-item delete-post-btn" data-post-id="${post._id}">
                                            🗑️ Deletar
                                        </button>
                                    </div>
                                </div>
                            `
                                : ""
                            }
                        </div>
                        
                        <div class="post-text">${this.escapeHtml(post.content)}</div>
                        
                        <div class="post-actions">
                            <button class="post-action">
                                <span>💬</span>
                                <span>0</span>
                            </button>
                            
                            <button class="post-action">
                                <span>🔄</span>
                                <span>0</span>
                            </button>
                            
                            <button class="post-action like-btn" data-post-id="${post._id}">
                                <span class="like-icon">🤍</span>
                                <span class="like-count">0</span>
                            </button>
                            
                            <button class="post-action">
                                <span>📤</span>
                            </button>
                        </div>
                    </div>
                </div>
            </article>
        `
  }

  /**
   * Obtém dados do formulário de edição
   * @returns {Object} Dados para atualização
   */
  getEditData() {
    return {
      username: this.editUsername.value.trim(),
      email: this.editEmail.value.trim(),
    }
  }

  /**
   * Mostra erro no formulário de edição
   * @param {string} message - Mensagem de erro
   */
  showError(message) {
    this.profileEditError.textContent = message
    this.profileEditError.classList.remove("hidden")
  }

  /**
   * Limpa mensagem de erro
   */
  clearError() {
    this.profileEditError.classList.add("hidden")
  }

  /**
   * Define estado de loading para edição
   * @param {boolean} loading - Estado de loading
   */
  setEditLoading(loading) {
    const btn = this.profileEditForm.querySelector('button[type="submit"]')
    const btnText = btn.querySelector(".btn-text")
    const btnLoading = btn.querySelector(".btn-loading")

    btn.disabled = loading
    this.editUsername.disabled = loading
    this.editEmail.disabled = loading

    if (loading) {
      btnText.classList.add("hidden")
      btnLoading.classList.remove("hidden")
      btn.classList.add("btn-loading")
    } else {
      btnText.classList.remove("hidden")
      btnLoading.classList.add("hidden")
      btn.classList.remove("btn-loading")
    }
  }

  /**
   * Remove post do DOM
   * @param {string} postId - ID do post
   */
  removePost(postId) {
    const postElement = this.userPostsContainer.querySelector(`[data-post-id="${postId}"]`)
    if (postElement) {
      postElement.remove()

      // Atualizar contador
      const remainingPosts = this.userPostsContainer.querySelectorAll(".post-card").length
      this.userPostsTitle.textContent = `Seus posts (${remainingPosts})`

      // Mostrar mensagem se não há posts
      if (remainingPosts === 0) {
        this.userPostsContainer.classList.add("hidden")
        this.noUserPosts.classList.remove("hidden")
      }
    }
  }

  /**
   * Formata data para exibição
   * @param {string} dateString - Data em string
   * @returns {string} Data formatada
   */
  formatDate(dateString) {
    return new Date(dateString).toLocaleDateString("pt-BR", {
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  }

  /**
   * Escapa HTML para prevenir XSS
   * @param {string} text - Texto para escapar
   * @returns {string} Texto escapado
   */
  escapeHtml(text) {
    const div = document.createElement("div")
    div.textContent = text
    return div.innerHTML
  }

  /**
   * Valida dados de edição
   * @param {Object} data - Dados para validação
   * @returns {boolean} True se válido
   */
  validateEditData(data) {
    if (!data.username || !data.email) {
      this.showError("Todos os campos são obrigatórios")
      return false
    }

    if (data.username.length < 3) {
      this.showError("Nome de usuário deve ter pelo menos 3 caracteres")
      return false
    }

    if (!this.isValidEmail(data.email)) {
      this.showError("Email inválido")
      return false
    }

    return true
  }

  /**
   * Valida formato de email
   * @param {string} email - Email para validação
   * @returns {boolean} True se válido
   */
  isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    return emailRegex.test(email)
  }
}
