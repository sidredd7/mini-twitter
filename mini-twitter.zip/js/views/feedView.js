/**
 * View para gerenciamento da interface do feed
 * Responsável por manipular elementos DOM relacionados aos posts
 */
class FeedView {
  constructor() {
    this.initializeElements()
    this.bindEvents()
  }

  /**
   * Inicializa referências aos elementos DOM
   */
  initializeElements() {
    // Containers principais
    this.appContainer = document.getElementById("app-container")
    this.usernameDisplay = document.getElementById("username-display")
    this.userAvatar = document.getElementById("user-avatar")

    // Formulário de criação de post
    this.createPostForm = document.getElementById("create-post-form")
    this.postContent = document.getElementById("post-content")
    this.charCount = document.getElementById("char-count")

    // Feed de posts
    this.postsContainer = document.getElementById("posts-container")
    this.postsLoading = document.getElementById("posts-loading")
    this.noPosts = document.getElementById("no-posts")

    // Botões do header
    this.profileBtn = document.getElementById("profile-btn")
    this.logoutBtn = document.getElementById("logout-btn")
    this.themeToggle = document.getElementById("theme-toggle")
  }

  /**
   * Vincula eventos aos elementos
   */
  bindEvents() {
    // Contador de caracteres
    this.postContent.addEventListener("input", () => this.updateCharCount())

    // Fechar menus ao clicar fora
    document.addEventListener("click", (e) => this.closePostMenus(e))
  }

  /**
   * Mostra o container da aplicação
   */
  show() {
    this.appContainer.classList.remove("hidden")
  }

  /**
   * Esconde o container da aplicação
   */
  hide() {
    this.appContainer.classList.add("hidden")
  }

  /**
   * Inicializa a interface com dados do usuário
   * @param {Object} user - Dados do usuário
   */
  initializeUser(user) {
    this.usernameDisplay.textContent = user.username
    this.userAvatar.textContent = user.username.charAt(0).toUpperCase()
  }

  /**
   * Atualiza contador de caracteres
   */
  updateCharCount() {
    const length = this.postContent.value.length
    const maxLength = 280

    this.charCount.textContent = `${length}/${maxLength}`

    // Atualiza classes baseado no limite
    this.charCount.classList.remove("warning", "error")

    if (length > maxLength * 0.9) {
      this.charCount.classList.add("warning")
    }

    if (length > maxLength) {
      this.charCount.classList.add("error")
    }
  }

  /**
   * Obtém conteúdo do novo post
   * @returns {string} Conteúdo do post
   */
  getPostContent() {
    return this.postContent.value.trim()
  }

  /**
   * Limpa formulário de criação de post
   */
  clearPostForm() {
    this.postContent.value = ""
    this.updateCharCount()
  }

  /**
   * Define estado de loading para criação de post
   * @param {boolean} loading - Estado de loading
   */
  setCreatePostLoading(loading) {
    const btn = this.createPostForm.querySelector('button[type="submit"]')
    const btnText = btn.querySelector(".btn-text")
    const btnLoading = btn.querySelector(".btn-loading")

    btn.disabled = loading
    this.postContent.disabled = loading

    if (loading) {
      btnText.classList.add("hidden")
      btnLoading.classList.remove("hidden")
      btn.classList.add("btn-loading")
    } else {
      btnText.classList.remove("hidden")
      btnLoading.classList.add("hidden")
      btn.classList.remove("btn-loading")
    }
  }

  /**
   * Mostra loading dos posts
   */
  showPostsLoading() {
    this.postsLoading.classList.remove("hidden")
    this.postsContainer.classList.add("hidden")
    this.noPosts.classList.add("hidden")
  }

  /**
   * Esconde loading dos posts
   */
  hidePostsLoading() {
    this.postsLoading.classList.add("hidden")
  }

  /**
   * Renderiza lista de posts
   * @param {Array} posts - Lista de posts
   * @param {string} currentUserId - ID do usuário atual
   */
  renderPosts(posts, currentUserId) {
    this.hidePostsLoading()

    if (posts.length === 0) {
      this.postsContainer.classList.add("hidden")
      this.noPosts.classList.remove("hidden")
      return
    }

    this.noPosts.classList.add("hidden")
    this.postsContainer.classList.remove("hidden")

    this.postsContainer.innerHTML = posts.map((post) => this.createPostHTML(post, currentUserId)).join("")
  }

  /**
   * Cria HTML para um post
   * @param {Object} post - Dados do post
   * @param {string} currentUserId - ID do usuário atual
   * @returns {string} HTML do post
   */
  createPostHTML(post, currentUserId) {
    const isOwner = currentUserId === post.author._id
    const formattedDate = this.formatDate(post.createdAt)
    const authorInitial = post.author.username.charAt(0).toUpperCase()

    return `
            <article class="post-card" data-post-id="${post._id}">
                <div class="post-content">
                    <div class="post-avatar">
                        <div class="avatar">${authorInitial}</div>
                    </div>
                    
                    <div class="post-body">
                        <div class="post-header">
                            <span class="post-author">${post.author.username}</span>
                            <span class="post-date">· ${formattedDate}</span>
                            
                            ${
                              isOwner
                                ? `
                                <div class="post-menu">
                                    <button class="post-menu-btn" data-post-id="${post._id}">⋯</button>
                                    <div class="post-menu-dropdown hidden">
                                        <button class="post-menu-item delete-post-btn" data-post-id="${post._id}">
                                            🗑️ Deletar
                                        </button>
                                    </div>
                                </div>
                            `
                                : ""
                            }
                        </div>
                        
                        <div class="post-text">${this.escapeHtml(post.content)}</div>
                        
                        <div class="post-actions">
                            <button class="post-action">
                                <span>💬</span>
                                <span>0</span>
                            </button>
                            
                            <button class="post-action">
                                <span>🔄</span>
                                <span>0</span>
                            </button>
                            
                            <button class="post-action like-btn" data-post-id="${post._id}">
                                <span class="like-icon">🤍</span>
                                <span class="like-count">0</span>
                            </button>
                            
                            <button class="post-action">
                                <span>📤</span>
                            </button>
                        </div>
                    </div>
                </div>
            </article>
        `
  }

  /**
   * Formata data para exibição
   * @param {string} dateString - Data em string
   * @returns {string} Data formatada
   */
  formatDate(dateString) {
    const date = new Date(dateString)
    const now = new Date()
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60))

    if (diffInHours < 1) {
      const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60))
      return `${diffInMinutes}min`
    } else if (diffInHours < 24) {
      return `${diffInHours}h`
    } else {
      const diffInDays = Math.floor(diffInHours / 24)
      return `${diffInDays}d`
    }
  }

  /**
   * Escapa HTML para prevenir XSS
   * @param {string} text - Texto para escapar
   * @returns {string} Texto escapado
   */
  escapeHtml(text) {
    const div = document.createElement("div")
    div.textContent = text
    return div.innerHTML
  }

  /**
   * Toggle do menu de post
   * @param {string} postId - ID do post
   */
  togglePostMenu(postId) {
    const menu = document.querySelector(`[data-post-id="${postId}"] .post-menu-dropdown`)
    if (menu) {
      menu.classList.toggle("hidden")
    }
  }

  /**
   * Fecha todos os menus de post
   * @param {Event} e - Evento de clique
   */
  closePostMenus(e) {
    if (!e.target.closest(".post-menu")) {
      const menus = document.querySelectorAll(".post-menu-dropdown")
      menus.forEach((menu) => menu.classList.add("hidden"))
    }
  }

  /**
   * Remove post do DOM
   * @param {string} postId - ID do post
   */
  removePost(postId) {
    const postElement = document.querySelector(`[data-post-id="${postId}"]`)
    if (postElement) {
      postElement.remove()
    }
  }

  /**
   * Toggle do like em um post
   * @param {string} postId - ID do post
   */
  toggleLike(postId) {
    const likeBtn = document.querySelector(`[data-post-id="${postId}"] .like-btn`)
    const likeIcon = likeBtn.querySelector(".like-icon")
    const likeCount = likeBtn.querySelector(".like-count")

    const isLiked = likeBtn.classList.contains("liked")

    if (isLiked) {
      likeBtn.classList.remove("liked")
      likeIcon.textContent = "🤍"
      likeCount.textContent = "0"
    } else {
      likeBtn.classList.add("liked")
      likeIcon.textContent = "❤️"
      likeCount.textContent = "1"
    }
  }

  /**
   * Valida conteúdo do post
   * @param {string} content - Conteúdo para validação
   * @returns {boolean} True se válido
   */
  validatePostContent(content) {
    if (!content) {
      return false
    }

    if (content.length > 280) {
      return false
    }

    return true
  }
}
