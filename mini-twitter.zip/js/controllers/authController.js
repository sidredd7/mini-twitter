/**
 * Controller para gerenciamento de autenticação
 * Coordena interações entre AuthView e AuthRepository
 */
class AuthController {
  constructor() {
    this.authRepository = new AuthRepository()
    this.authView = new AuthView()
    this.bindEvents()
  }

  /**
   * Vincula eventos da view
   */
  bindEvents() {
    // Formulário de login
    this.authView.loginFormElement.addEventListener("submit", (e) => {
      e.preventDefault()
      this.handleLogin()
    })

    // Formulário de registro
    this.authView.registerFormElement.addEventListener("submit", (e) => {
      e.preventDefault()
      this.handleRegister()
    })
  }

  /**
   * Processa login do usuário
   */
  async handleLogin() {
    console.log("Iniciando processo de login...")
    const loginData = this.authView.getLoginData()

    // Validação
    if (!this.authView.validateLoginData(loginData)) {
      console.log("Validação de login falhou")
      return
    }

    this.authView.setLoginLoading(true)
    this.authView.clearErrors()

    try {
      console.log("Enviando requisição de login...")
      const response = await this.authRepository.login(loginData)
      console.log("Login bem-sucedido:", response)

      // Salvar dados de autenticação
      this.authRepository.saveAuthData(response.token, response.user)

      // Notificar sucesso
      this.onAuthSuccess()
    } catch (error) {
      console.error("Erro no login:", error)
      this.authView.showLoginError(error.message || "Erro de conexão. Tente novamente.")
    } finally {
      this.authView.setLoginLoading(false)
    }
  }

  /**
   * Processa registro do usuário
   */
  async handleRegister() {
    console.log("Iniciando processo de registro...")
    const registerData = this.authView.getRegisterData()

    // Validação
    if (!this.authView.validateRegisterData(registerData)) {
      console.log("Validação de registro falhou")
      return
    }

    this.authView.setRegisterLoading(true)
    this.authView.clearErrors()

    try {
      console.log("Enviando requisição de registro...")
      const response = await this.authRepository.register(registerData)
      console.log("Registro bem-sucedido:", response)

      // Salvar dados de autenticação
      this.authRepository.saveAuthData(response.token, response.user)

      // Notificar sucesso
      this.onAuthSuccess()
    } catch (error) {
      console.error("Erro no registro:", error)
      this.authView.showRegisterError(error.message || "Erro de conexão. Tente novamente.")
    } finally {
      this.authView.setRegisterLoading(false)
    }
  }

  /**
   * Verifica se usuário está autenticado
   * @returns {boolean} True se autenticado
   */
  isAuthenticated() {
    return this.authRepository.isAuthenticated()
  }

  /**
   * Obtém dados do usuário atual
   * @returns {Object|null} Dados do usuário
   */
  getCurrentUser() {
    return this.authRepository.getUser()
  }

  /**
   * Mostra interface de autenticação
   */
  showAuth() {
    this.authView.show()
  }

  /**
   * Esconde interface de autenticação
   */
  hideAuth() {
    this.authView.hide()
  }

  /**
   * Callback para sucesso na autenticação
   */
  onAuthSuccess() {
    // Este método será sobrescrito pelo AppController
    console.log("Autenticação realizada com sucesso")
  }

  /**
   * Realiza logout
   */
  logout() {
    this.authRepository.clearAuthData()
    window.location.reload()
  }
}
