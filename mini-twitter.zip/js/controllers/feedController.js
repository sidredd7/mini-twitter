/**
 * Controller para gerenciamento do feed
 * Coordena interações entre FeedView e PostRepository
 */
class FeedController {
  constructor() {
    this.postRepository = new PostRepository()
    this.feedView = new FeedView()
    this.authRepository = new AuthRepository()
    this.bindEvents()
  }

  /**
   * Vincula eventos da view
   */
  bindEvents() {
    // Formulário de criação de post
    this.feedView.createPostForm.addEventListener("submit", (e) => {
      e.preventDefault()
      this.handleCreatePost()
    })

    // Botão de logout
    this.feedView.logoutBtn.addEventListener("click", () => {
      this.handleLogout()
    })

    // Eventos de posts (delegação)
    this.feedView.postsContainer.addEventListener("click", (e) => {
      this.handlePostActions(e)
    })
  }

  /**
   * Inicializa o feed
   */
  async initialize() {
    const user = this.authRepository.getUser()
    if (!user) return

    // Inicializar interface com dados do usuário
    this.feedView.initializeUser(user)

    // Carregar posts
    await this.loadPosts()
  }

  /**
   * Carrega todos os posts
   */
  async loadPosts() {
    console.log("Carregando posts...")
    this.feedView.showPostsLoading()

    try {
      const posts = await this.postRepository.getAllPosts()
      const currentUser = this.authRepository.getUser()
      console.log("Posts carregados:", posts.length)

      this.feedView.renderPosts(posts, currentUser.id)
    } catch (error) {
      console.error("Erro ao carregar posts:", error)
      this.feedView.hidePostsLoading()

      // Mostrar mensagem de erro mais amigável
      if (error.message.includes("401") || error.message.includes("Não autorizado")) {
        alert("Sua sessão expirou. Faça login novamente.")
        this.authRepository.clearAuthData()
        window.location.reload()
      } else {
        alert("Erro ao carregar posts. Verifique sua conexão e tente novamente.")
      }
    }
  }

  /**
   * Processa criação de novo post
   */
  async handleCreatePost() {
    const content = this.feedView.getPostContent()
    console.log("Criando post com conteúdo:", content)

    // Validação
    if (!this.feedView.validatePostContent(content)) {
      console.log("Validação do post falhou")
      return
    }

    this.feedView.setCreatePostLoading(true)

    try {
      await this.postRepository.createPost(content)
      console.log("Post criado com sucesso")

      // Limpar formulário
      this.feedView.clearPostForm()

      // Recarregar posts
      await this.loadPosts()
    } catch (error) {
      console.error("Erro ao criar post:", error)

      if (error.message.includes("401") || error.message.includes("Não autorizado")) {
        alert("Sua sessão expirou. Faça login novamente.")
        this.authRepository.clearAuthData()
        window.location.reload()
      } else {
        alert("Erro ao criar post. Tente novamente.")
      }
    } finally {
      this.feedView.setCreatePostLoading(false)
    }
  }

  /**
   * Processa ações nos posts (like, delete, menu)
   * @param {Event} e - Evento de clique
   */
  handlePostActions(e) {
    const target = e.target.closest("button")
    if (!target) return

    const postId = target.dataset.postId

    // Menu do post
    if (target.classList.contains("post-menu-btn")) {
      e.stopPropagation()
      this.feedView.togglePostMenu(postId)
      return
    }

    // Deletar post
    if (target.classList.contains("delete-post-btn")) {
      this.handleDeletePost(postId)
      return
    }

    // Like no post
    if (target.classList.contains("like-btn")) {
      this.feedView.toggleLike(postId)
      return
    }
  }

  /**
   * Processa exclusão de post
   * @param {string} postId - ID do post
   */
  async handleDeletePost(postId) {
    if (!confirm("Tem certeza que deseja deletar este post?")) {
      return
    }

    try {
      await this.postRepository.deletePost(postId)

      // Remover post da interface
      this.feedView.removePost(postId)
    } catch (error) {
      console.error("Erro ao deletar post:", error)
      alert("Erro ao deletar post. Tente novamente.")
    }
  }

  /**
   * Processa logout
   */
  handleLogout() {
    if (confirm("Tem certeza que deseja sair?")) {
      this.authRepository.clearAuthData()
      window.location.reload()
    }
  }

  /**
   * Mostra interface do feed
   */
  show() {
    this.feedView.show()
  }

  /**
   * Esconde interface do feed
   */
  hide() {
    this.feedView.hide()
  }
}
