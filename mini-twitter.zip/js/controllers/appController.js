/**
 * Controller principal da aplicação
 * Coordena todos os outros controllers e gerencia o estado global
 */
class AppController {
  constructor() {
    this.authController = new AuthController()
    this.feedController = new FeedController()
    this.profileController = new ProfileController()

    this.initializeApp()
    this.bindEvents()

    // Inicializar tema
    this.initializeTheme()
  }

  /**
   * Inicializa a aplicação
   */
  async initializeApp() {
    console.log("Inicializando aplicação...")

    // Verificar conectividade
    if (!navigator.onLine) {
      console.warn("Aplicação iniciada offline")
      alert("Você está offline. Algumas funcionalidades podem não funcionar.")
    }

    // Esconder loading inicial
    this.hideLoading()

    // Verificar autenticação
    if (this.authController.isAuthenticated()) {
      console.log("Usuário autenticado, carregando app principal...")
      await this.showMainApp()
    } else {
      console.log("Usuário não autenticado, mostrando tela de login...")
      this.showAuth()
    }
  }

  /**
   * Vincula eventos globais
   */
  bindEvents() {
    // Callback de sucesso na autenticação
    this.authController.onAuthSuccess = () => {
      this.showMainApp()
    }

    // Botão de perfil no header
    const profileBtn = document.getElementById("profile-btn")
    if (profileBtn) {
      profileBtn.addEventListener("click", () => {
        this.profileController.show()
      })
    }

    // Callback de atualização de usuário
    this.profileController.setUserUpdateCallback((user) => {
      this.updateUserDisplay(user)
    })

    // Toggle de tema
    const themeToggle = document.getElementById("theme-toggle")
    if (themeToggle) {
      themeToggle.addEventListener("click", () => {
        this.toggleTheme()
      })
    }

    // Tratamento de erros de rede global
    window.addEventListener("online", () => {
      console.log("Conexão restaurada")
    })

    window.addEventListener("offline", () => {
      console.log("Conexão perdida")
      alert("Você está offline. Algumas funcionalidades podem não funcionar.")
    })
  }

  /**
   * Mostra interface de autenticação
   */
  showAuth() {
    this.feedController.hide()
    this.authController.showAuth()
  }

  /**
   * Mostra aplicação principal
   */
  async showMainApp() {
    try {
      this.authController.hideAuth()
      this.feedController.show()

      // Inicializar feed
      console.log("Inicializando feed...")
      await this.feedController.initialize()
      console.log("Feed inicializado com sucesso")
    } catch (error) {
      console.error("Erro ao inicializar app principal:", error)

      // Se houver erro de autenticação, voltar para login
      if (error.message.includes("401") || error.message.includes("Não autorizado")) {
        this.authController.logout()
      } else {
        alert("Erro ao carregar a aplicação. Tente novamente.")
      }
    }
  }

  /**
   * Atualiza exibição do usuário na interface
   * @param {Object} user - Dados atualizados do usuário
   */
  updateUserDisplay(user) {
    const usernameDisplay = document.getElementById("username-display")
    const userAvatar = document.getElementById("user-avatar")

    if (usernameDisplay) {
      usernameDisplay.textContent = user.username
    }

    if (userAvatar) {
      userAvatar.textContent = user.username.charAt(0).toUpperCase()
    }
  }

  /**
   * Esconde tela de loading inicial
   */
  hideLoading() {
    const loading = document.getElementById("loading")
    if (loading) {
      loading.classList.add("hidden")
    }
  }

  /**
   * Tratamento global de erros
   * @param {Error} error - Erro capturado
   */
  handleGlobalError(error) {
    console.error("Erro global:", error)

    // Se for erro de autenticação, redirecionar para login
    if (error.message.includes("401") || error.message.includes("Não autorizado")) {
      this.authController.logout()
      return
    }

    // Mostrar mensagem genérica para outros erros
    alert("Ocorreu um erro inesperado. Tente novamente.")
  }

  /**
   * Inicializa o tema da aplicação
   */
  initializeTheme() {
    // Verificar tema salvo no localStorage
    const savedTheme = localStorage.getItem("theme")
    const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches

    // Definir tema inicial
    const initialTheme = savedTheme || (prefersDark ? "dark" : "light")
    this.setTheme(initialTheme)

    // Escutar mudanças na preferência do sistema
    window.matchMedia("(prefers-color-scheme: dark)").addEventListener("change", (e) => {
      if (!localStorage.getItem("theme")) {
        this.setTheme(e.matches ? "dark" : "light")
      }
    })
  }

  /**
   * Define o tema da aplicação
   * @param {string} theme - 'light' ou 'dark'
   */
  setTheme(theme) {
    document.documentElement.setAttribute("data-theme", theme)
    localStorage.setItem("theme", theme)

    // Atualizar ícone do toggle se existir
    const themeToggle = document.getElementById("theme-toggle")
    if (themeToggle) {
      themeToggle.setAttribute("title", theme === "dark" ? "Mudar para tema claro" : "Mudar para tema escuro")
    }
  }

  /**
   * Alterna entre tema claro e escuro
   */
  toggleTheme() {
    const currentTheme = document.documentElement.getAttribute("data-theme")
    const newTheme = currentTheme === "dark" ? "light" : "dark"
    this.setTheme(newTheme)
  }

  /**
   * Obtém o tema atual
   * @returns {string} Tema atual
   */
  getCurrentTheme() {
    return document.documentElement.getAttribute("data-theme") || "light"
  }
}

// Inicializar aplicação quando DOM estiver carregado
document.addEventListener("DOMContentLoaded", () => {
  // Verificar suporte a recursos necessários
  if (!window.localStorage) {
    alert("Seu navegador não suporta localStorage. A aplicação pode não funcionar corretamente.")
    return
  }

  if (!window.fetch) {
    alert("Seu navegador não suporta fetch API. Por favor, atualize seu navegador.")
    return
  }

  // Inicializar aplicação
  window.app = new AppController()
})

// Tratamento de erros não capturados
window.addEventListener("unhandledrejection", (event) => {
  console.error("Promise rejeitada:", event.reason)
  if (window.app) {
    window.app.handleGlobalError(event.reason)
  }
})

window.addEventListener("error", (event) => {
  console.error("Erro JavaScript:", event.error)
  if (window.app) {
    window.app.handleGlobalError(event.error)
  }
})
