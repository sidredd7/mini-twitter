/**
 * Controller para gerenciamento do perfil
 * Coordena interações entre ProfileView, UserRepository e PostRepository
 */
class ProfileController {
  constructor() {
    this.userRepository = new UserRepository()
    this.postRepository = new PostRepository()
    this.profileView = new ProfileView()
    this.authRepository = new AuthRepository()
    this.bindEvents()
  }

  /**
   * Vincula eventos da view
   */
  bindEvents() {
    // Formulário de edição de perfil
    this.profileView.profileEditForm.addEventListener("submit", (e) => {
      e.preventDefault()
      this.handleUpdateProfile()
    })

    // Eventos de posts do usuário (delegação)
    this.profileView.userPostsContainer.addEventListener("click", (e) => {
      this.handleUserPostActions(e)
    })
  }

  /**
   * Mostra modal de perfil e carrega dados
   */
  async show() {
    this.profileView.show()
    await this.loadProfileData()
  }

  /**
   * Carrega dados do perfil e posts do usuário
   */
  async loadProfileData() {
    try {
      // Carregar perfil
      const profile = await this.userRepository.getProfile()
      this.profileView.renderProfile(profile)

      // Carregar posts do usuário
      const userPosts = await this.postRepository.getUserPosts()
      const currentUser = this.authRepository.getUser()
      this.profileView.renderUserPosts(userPosts, currentUser.id)
    } catch (error) {
      console.error("Erro ao carregar dados do perfil:", error)
      alert("Erro ao carregar perfil. Tente novamente.")
    }
  }

  /**
   * Processa atualização do perfil
   */
  async handleUpdateProfile() {
    const editData = this.profileView.getEditData()

    // Validação
    if (!this.profileView.validateEditData(editData)) {
      return
    }

    this.profileView.setEditLoading(true)
    this.profileView.clearError()

    try {
      const response = await this.userRepository.updateProfile(editData)

      // Atualizar dados locais
      this.userRepository.updateLocalUserData(response.user)

      // Atualizar interface
      this.profileView.renderProfile(response.user)
      this.profileView.hideEditMode()

      // Notificar callback se existir
      if (this.onUserUpdate) {
        this.onUserUpdate(response.user)
      }
    } catch (error) {
      this.profileView.showError(error.message)
    } finally {
      this.profileView.setEditLoading(false)
    }
  }

  /**
   * Processa ações nos posts do usuário
   * @param {Event} e - Evento de clique
   */
  handleUserPostActions(e) {
    const target = e.target.closest("button")
    if (!target) return

    const postId = target.dataset.postId

    // Menu do post
    if (target.classList.contains("post-menu-btn")) {
      e.stopPropagation()
      // Implementar toggle do menu se necessário
      return
    }

    // Deletar post
    if (target.classList.contains("delete-post-btn")) {
      this.handleDeleteUserPost(postId)
      return
    }
  }

  /**
   * Processa exclusão de post do usuário
   * @param {string} postId - ID do post
   */
  async handleDeleteUserPost(postId) {
    if (!confirm("Tem certeza que deseja deletar este post?")) {
      return
    }

    try {
      await this.postRepository.deletePost(postId)

      // Remover post da interface
      this.profileView.removePost(postId)
    } catch (error) {
      console.error("Erro ao deletar post:", error)
      alert("Erro ao deletar post. Tente novamente.")
    }
  }

  /**
   * Define callback para atualização de usuário
   * @param {Function} callback - Função callback
   */
  setUserUpdateCallback(callback) {
    this.onUserUpdate = callback
  }
}
