/**
 * Repository para operações de posts
 * Responsável por comunicação com a API de posts
 */
class PostRepository {
  constructor() {
    this.baseUrl = "https://mini-twitter-api-vy9q.onrender.com/api/posts"
  }

  /**
   * Obtém headers com autorização
   * @returns {Object} Headers para requisições autenticadas
   */
  getAuthHeaders() {
    const token = localStorage.getItem("token")
    if (!token) {
      throw new Error("Token de autenticação não encontrado")
    }
    return {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    }
  }

  /**
   * Cria um novo post
   * @param {string} content - Conteúdo do post
   * @returns {Promise<Object>} Post criado
   */
  async createPost(content) {
    try {
      console.log("PostRepository: Criando post...")

      const controller = new AbortController()
      const timeoutId = setTimeout(() => controller.abort(), 10000)

      const response = await fetch(this.baseUrl, {
        method: "POST",
        headers: this.getAuthHeaders(),
        body: JSON.stringify({ content }),
        signal: controller.signal,
      })

      clearTimeout(timeoutId)
      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.message || "Erro ao criar post")
      }

      return data
    } catch (error) {
      if (error.name === "AbortError") {
        throw new Error("Timeout: A requisição demorou muito para responder")
      }
      console.error("Erro ao criar post:", error)
      throw error
    }
  }

  /**
   * Lista todos os posts
   * @returns {Promise<Array>} Lista de posts
   */
  async getAllPosts() {
    try {
      console.log("PostRepository: Carregando todos os posts...")

      const controller = new AbortController()
      const timeoutId = setTimeout(() => controller.abort(), 10000)

      const response = await fetch(this.baseUrl, {
        headers: this.getAuthHeaders(),
        signal: controller.signal,
      })

      clearTimeout(timeoutId)
      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.message || "Erro ao carregar posts")
      }

      console.log("PostRepository: Posts carregados:", data.length)
      return data
    } catch (error) {
      if (error.name === "AbortError") {
        throw new Error("Timeout: A requisição demorou muito para responder")
      }
      console.error("Erro ao carregar posts:", error)
      throw error
    }
  }

  /**
   * Lista posts do usuário logado
   * @returns {Promise<Array>} Lista de posts do usuário
   */
  async getUserPosts() {
    try {
      const response = await fetch(`${this.baseUrl}/my-posts`, {
        headers: this.getAuthHeaders(),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.message || "Erro ao carregar seus posts")
      }

      return data
    } catch (error) {
      console.error("Erro ao carregar posts do usuário:", error)
      throw error
    }
  }

  /**
   * Deleta um post
   * @param {string} postId - ID do post
   * @returns {Promise<Object>} Resposta da API
   */
  async deletePost(postId) {
    try {
      const response = await fetch(`${this.baseUrl}/${postId}`, {
        method: "DELETE",
        headers: this.getAuthHeaders(),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.message || "Erro ao deletar post")
      }

      return data
    } catch (error) {
      console.error("Erro ao deletar post:", error)
      throw error
    }
  }
}
