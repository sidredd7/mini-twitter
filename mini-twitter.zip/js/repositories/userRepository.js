/**
 * Repository para operações de usuário
 * Responsável por comunicação com a API de usuários
 */
class UserRepository {
  constructor() {
    this.baseUrl = "https://mini-twitter-api-vy9q.onrender.com/api/users"
  }

  /**
   * Obtém headers com autorização
   * @returns {Object} Headers para requisições autenticadas
   */
  getAuthHeaders() {
    const token = localStorage.getItem("token")
    return {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    }
  }

  /**
   * Obtém perfil do usuário logado
   * @returns {Promise<Object>} Dados do perfil
   */
  async getProfile() {
    try {
      const response = await fetch(`${this.baseUrl}/profile`, {
        headers: this.getAuthHeaders(),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.message || "Erro ao carregar perfil")
      }

      return data
    } catch (error) {
      console.error("Erro ao carregar perfil:", error)
      throw error
    }
  }

  /**
   * Atualiza perfil do usuário
   * @param {Object} profileData - Dados para atualização (username, email)
   * @returns {Promise<Object>} Perfil atualizado
   */
  async updateProfile(profileData) {
    try {
      const response = await fetch(`${this.baseUrl}/profile`, {
        method: "PUT",
        headers: this.getAuthHeaders(),
        body: JSON.stringify(profileData),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.message || "Erro ao atualizar perfil")
      }

      return data
    } catch (error) {
      console.error("Erro ao atualizar perfil:", error)
      throw error
    }
  }

  /**
   * Atualiza dados do usuário no localStorage
   * @param {Object} userData - Novos dados do usuário
   */
  updateLocalUserData(userData) {
    localStorage.setItem("user", JSON.stringify(userData))
  }
}
