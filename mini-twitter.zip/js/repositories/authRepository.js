/**
 * Repository para operações de autenticação
 * Responsável por comunicação com a API de auth
 */
class AuthRepository {
  constructor() {
    this.baseUrl = "https://mini-twitter-api-vy9q.onrender.com/api/auth"
  }

  /**
   * Registra um novo usuário
   * @param {Object} userData - Dados do usuário (username, email, password)
   * @returns {Promise<Object>} Resposta da API
   */
  async register(userData) {
    try {
      console.log("AuthRepository: Enviando dados de registro:", { ...userData, password: "[HIDDEN]" })

      const controller = new AbortController()
      const timeoutId = setTimeout(() => controller.abort(), 10000) // 10 segundos timeout

      const response = await fetch(`${this.baseUrl}/register`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(userData),
        signal: controller.signal,
      })

      clearTimeout(timeoutId)
      console.log("AuthRepository: Resposta recebida:", response.status)

      const data = await response.json()
      console.log("AuthRepository: Dados da resposta:", data)

      if (!response.ok) {
        throw new Error(data.message || "Erro ao criar conta")
      }

      return data
    } catch (error) {
      if (error.name === "AbortError") {
        throw new Error("Timeout: A requisição demorou muito para responder")
      }
      console.error("Erro no registro:", error)
      throw error
    }
  }

  /**
   * Realiza login do usuário
   * @param {Object} credentials - Credenciais (email, password)
   * @returns {Promise<Object>} Resposta da API
   */
  async login(credentials) {
    try {
      console.log("AuthRepository: Enviando credenciais de login:", { ...credentials, password: "[HIDDEN]" })

      const controller = new AbortController()
      const timeoutId = setTimeout(() => controller.abort(), 10000) // 10 segundos timeout

      const response = await fetch(`${this.baseUrl}/login`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(credentials),
        signal: controller.signal,
      })

      clearTimeout(timeoutId)
      console.log("AuthRepository: Resposta recebida:", response.status)

      const data = await response.json()
      console.log("AuthRepository: Dados da resposta:", data)

      if (!response.ok) {
        throw new Error(data.message || "Erro ao fazer login")
      }

      return data
    } catch (error) {
      if (error.name === "AbortError") {
        throw new Error("Timeout: A requisição demorou muito para responder")
      }
      console.error("Erro no login:", error)
      throw error
    }
  }

  /**
   * Salva dados de autenticação no localStorage
   * @param {string} token - Token JWT
   * @param {Object} user - Dados do usuário
   */
  saveAuthData(token, user) {
    localStorage.setItem("token", token)
    localStorage.setItem("user", JSON.stringify(user))
  }

  /**
   * Recupera token do localStorage
   * @returns {string|null} Token JWT ou null
   */
  getToken() {
    return localStorage.getItem("token")
  }

  /**
   * Recupera dados do usuário do localStorage
   * @returns {Object|null} Dados do usuário ou null
   */
  getUser() {
    const userData = localStorage.getItem("user")
    return userData ? JSON.parse(userData) : null
  }

  /**
   * Remove dados de autenticação do localStorage
   */
  clearAuthData() {
    localStorage.removeItem("token")
    localStorage.removeItem("user")
  }

  /**
   * Verifica se o usuário está autenticado
   * @returns {boolean} True se autenticado
   */
  isAuthenticated() {
    return !!this.getToken()
  }
}
