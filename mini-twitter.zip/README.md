# Mini Twitter

Uma versão simplificada do Twitter desenvolvida com HTML5, CSS3 e JavaScript vanilla, inspirada no design do Threads.

## 📋 Funcionalidades

### 🔐 Sistema de Autenticação
- **Registro de usuários** com validação de dados
- **Login seguro** com JWT tokens
- **Persistência de sessão** usando localStorage
- **Logout** com limpeza de dados

### 📱 Feed de Posts
- **Criar posts** com limite de 280 caracteres
- **Visualizar feed** em tempo real
- **Interações** (like, comentário, compartilhar)
- **Deletar posts** próprios

### 👤 Perfil do Usuário
- **Visualizar perfil** completo
- **Editar informações** (username e email)
- **Histórico de posts** do usuário
- **Estatísticas** de atividade

### 🎨 Interface e Temas
- **Tema claro/escuro** com toggle automático
- **Detecção automática** da preferência do sistema
- **Persistência** da escolha do usuário
- **Transições suaves** entre temas

## 🚀 Tecnologias Utilizadas

- **HTML5** semântico
- **CSS3** com Flexbox e Grid
- **JavaScript ES6+** vanilla
- **API REST** para backend
- **localStorage** para persistência
- **Design responsivo** mobile-first

## 📁 Estrutura do Projeto

\`\`\`
mini-twitter/
├── index.html                 # Página principal
├── css/
│   ├── reset.css             # Reset CSS
│   └── style.css             # Estilos principais
├── js/
│   ├── controllers/          # Controllers (MVC)
│   │   ├── appController.js
│   │   ├── authController.js
│   │   ├── feedController.js
│   │   └── profileController.js
│   ├── views/               # Views (MVC)
│   │   ├── authView.js
│   │   ├── feedView.js
│   │   └── profileView.js
│   └── repositories/        # Repositories (Data Layer)
│       ├── authRepository.js
│       ├── postRepository.js
│       └── userRepository.js
└── README.md
\`\`\`

## 🌙 Tema Escuro

A aplicação suporta tema escuro com as seguintes características:

### Funcionalidades
- **Toggle manual** no header da aplicação
- **Detecção automática** da preferência do sistema operacional
- **Persistência** da escolha no localStorage
- **Transições suaves** entre temas

### Como usar
1. **Automático**: A aplicação detecta automaticamente se você prefere tema escuro
2. **Manual**: Clique no botão de sol/lua no header para alternar
3. **Persistente**: Sua escolha é salva e mantida entre sessões

### Implementação técnica
- CSS Custom Properties para variáveis de cor
- `prefers-color-scheme` media query para detecção automática
- localStorage para persistência
- Transições CSS para mudanças suaves

## 🔧 Instalação e Uso

### Pré-requisitos
- Navegador web moderno (Chrome, Firefox, Safari, Edge)
- Conexão com internet (para API)

### Instalação
1. Clone ou baixe o repositório
2. Abra o arquivo `index.html` em um navegador
3. A aplicação estará pronta para uso!

### Uso
1. **Primeiro acesso**: Clique em "Cadastre-se" para criar uma conta
2. **Login**: Use suas credenciais para entrar
3. **Criar posts**: Digite seu pensamento e clique em "Publicar"
4. **Interagir**: Curta, comente ou compartilhe posts
5. **Perfil**: Clique no seu nome para ver/editar perfil

## 🌐 API

A aplicação utiliza a API REST disponível em:
`https://mini-twitter-api-vy9q.onrender.com/`

### Endpoints utilizados:
- `POST /api/auth/register` - Registro de usuários
- `POST /api/auth/login` - Login de usuários
- `GET /api/posts` - Listar todos os posts
- `POST /api/posts` - Criar novo post
- `DELETE /api/posts/:id` - Deletar post
- `GET /api/posts/my-posts` - Posts do usuário
- `GET /api/users/profile` - Perfil do usuário
- `PUT /api/users/profile` - Atualizar perfil

## 🎨 Design

O design foi inspirado no **Threads** (Instagram), com:
- Interface limpa e moderna
- Cards com bordas suaves
- Avatares circulares com iniciais
- Paleta de cores neutra
- Animações sutis
- Design responsivo

## 📱 Responsividade

A aplicação é totalmente responsiva, adaptando-se a:
- **Mobile** (320px+)
- **Tablet** (768px+)
- **Desktop** (1024px+)

## ♿ Acessibilidade

Implementações de acessibilidade:
- HTML semântico
- Labels apropriados
- Navegação por teclado
- Contraste adequado
- Textos alternativos
- Estados de foco visíveis

## 🔒 Segurança

Medidas de segurança implementadas:
- Escape de HTML para prevenir XSS
- Validação de dados no frontend
- Tokens JWT para autenticação
- Sanitização de inputs

## 🧪 Testes

Para testar a aplicação:
1. Teste em diferentes navegadores
2. Teste responsividade em vários dispositivos
3. Teste funcionalidades offline/online
4. Teste validações de formulários
5. Teste fluxos de erro

## 📊 Performance

Otimizações implementadas:
- CSS e JS minificados
- Lazy loading de conteúdo
- Debounce em inputs
- Cache de dados do usuário
- Animações otimizadas

## 🐛 Tratamento de Erros

A aplicação trata:
- Erros de rede
- Erros de API
- Validações de formulário
- Estados offline
- Timeouts de requisição

## 🔄 Funcionalidades Futuras

Possíveis melhorias:
- Upload de imagens
- Sistema de seguir usuários
- Notificações em tempo real
- Modo escuro
- Busca de posts
- Hashtags
- Comentários aninhados

## 📝 Licença

Este projeto é para fins educacionais.

## 👥 Contribuição

Para contribuir:
1. Fork o projeto
2. Crie uma branch para sua feature
3. Commit suas mudanças
4. Push para a branch
5. Abra um Pull Request

## 📞 Suporte

Em caso de dúvidas ou problemas:
- Verifique o console do navegador
- Teste em modo incógnito
- Limpe o localStorage se necessário
- Verifique conexão com internet
